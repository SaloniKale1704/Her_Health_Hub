document.addEventListener("DOMContentLoaded", function() {
    var searchButton = document.getElementById("searchButton");

    searchButton.addEventListener("click", function() {
        search();
    });

    function search() {
        var selectedDisease = document.getElementById("categorySelect").value;
        var table = document.getElementById("resultTable");
        var resultBody = document.getElementById("resultBody");
        var container = document.querySelector(".container");

        // Clear previous results
        resultBody.innerHTML = "";
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Fetch data based on selected disease
        // Example data
        var data = [];

        switch(selectedDisease.toLowerCase()) {
            case "breast cancer":
                data = [
                    { Mild: "Tamoxifen", Chronic: "Doxorubicin" },
                    { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
                    { Mild: "Lapatinib ", Chronic: "Capecitabine" },
                    { Mild: "Neratinib ", Chronic: "Cyclophosphamide" },
                    { Mild: "Palbociclib ", Chronic: "Carboplatin " },
                    { Mild: "Abemaciclib ", Chronic: "Evista " },
                    { Mild: "Pertuzumab ", Chronic: "Epirubicin " },
                    { Mild: "Trastuzumab ", Chronic: "Fluorouracil " },
                ];
                break;
                case "pcod":
                    data = [
                      { Mild: "PTamoxifen ", Chronic: "Doxorubicin" },
                      { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
                      { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
                      { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
                      { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
                      { Mild: "Abemaciclib ", Chronic: "Evista " },
                      { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
                      { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
                        ];
                    break;
                  case "thyroid":
                    data = [
                      { Mild: "TTamoxifen ", Chronic: "Doxorubicin" },
                      { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
                      { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
                      { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
                      { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
                      { Mild: "Abemaciclib ", Chronic: "Evista " },
                      { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
                      { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
                        ];
                    break;
                  case "cervical cancer":
                    data = [
                      { Mild: "CTamoxifen ", Chronic: "Doxorubicin" },
                      { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
                      { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
                      { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
                      { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
                      { Mild: "Abemaciclib ", Chronic: "Evista " },
                      { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
                      { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
                        ];
                    break;
                  case "uterian fibroids":
                    data = [
                      { Mild: "UTamoxifen ", Chronic: "Doxorubicin" },
                      { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
                      { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
                      { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
                      { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
                      { Mild: "Abemaciclib ", Chronic: "Evista " },
                      { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
                      { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
                        ];
                    break;
                  default:
                    break;
        }

        // Populate table with fetched data
        for (var i = 0; i < data.length; i++) {
            var row = document.createElement("tr");
            row.innerHTML = "<td>" + data[i].Mild + "</td><td>" + data[i].Chronic + "</td>";
            resultBody.appendChild(row);
        }

        // Show the table
        table.style.display = "table";

        // Add event listener to cells for additional drug details
        var cells = document.querySelectorAll("#resultBody td");
        cells.forEach(function(cell) {
            cell.addEventListener("click", function() {
                var drugName = cell.textContent.trim();
                showDrugDetails(drugName);
            });
        });
    }

    // Function to display additional drug details for the selected medication
    function showDrugDetails(drugName) {
        // Object containing drug details for each medication
        var drugDetails = {
            "Tamoxifen": {
                "Drug Name": "Tamoxifen",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Doxorubicin": {
                "Drug Name": "Doxorubicin",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Aromatase inhibitor": {
                "Drug Name": "Aromatase inhibitor",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Paclitaxel": {
                "Drug Name": "Paclitaxel",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Lapatinib": {
                "Drug Name": "Lapatinib",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Capecitabine": {
                "Drug Name": "Capecitabine",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Neratinib": {
                "Drug Name": "Neratinib",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Cyclophosphamide": {
                "Drug Name": "Cyclophosphamide",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Palbociclib": {
                "Drug Name": "Palbociclib",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Carboplatin": {
                "Drug Name": "Carboplatin",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Abemaciclib": {
                "Drug Name": "Abemaciclib",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Evista": {
                "Drug Name": "Evista",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Pertuzumab": {
                "Drug Name": "Pertuzumab",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Epirubicin": {
                "Drug Name": "Epirubicin",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Trastuzumab": {
                "Drug Name": "Trastuzumab",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            },
            "Fluorouracil": {
                "Drug Name": "Fluorouracil",
                "Receptor": "Used to treat breast cancer, as well as to prevent breast cancer in high-risk individuals.",
                "LogP Value": "Hot flashes, vaginal discharge, menstrual irregularities, increased risk of blood clots.",
                "Chemical Formula":"",
                "ADME":"",
                "Half Life":"",
                "Adverse Effects":"",
                "Food Interactions":""
            }
           
        };

        // Create a new table for drug details
        var drugTable = document.createElement("table");
        drugTable.classList.add("drug-details");
        drugTable.innerHTML = `
        <table border="1" align="center">
        <thead>
            <tr>
                <th colspan="8">
                    <h3 style="text-align: center;">${drugName} Details</h3>
                </th>
            </tr>
            <tr>
                <th>Drug Name</th>
                <th>Receptor</th>
                <th>LogP Value</th>
                <th>Chemical Formula</th>
                <th>ADME</th>
                <th>Half Life</th>
                <th>Adverse Effects</th>
                <th>Food Interactions</th>
            </tr> 
        </thead>
        <tbody>
            <tr>
                <td>${drugDetails[drugName]["Drug Name"]}</td>
                <td>${drugDetails[drugName]["Receptor"]}</td>
                <td>${drugDetails[drugName]["LogP Value"]}</td>
                <td>${drugDetails[drugName]["Chemical Formula"]}</td>
                <td>${drugDetails[drugName]["ADME"]}</td>
                <td>${drugDetails[drugName]["Half Life"]}</td>
                <td>${drugDetails[drugName]["Adverse Effects"]}</td>
                <td>${drugDetails[drugName]["Food Interactions"]}</td>
            </tr>
        </tbody>
    </table>
    
        `;

        // Clear previous drug details tables
        var container = document.querySelector(".container");
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Append the drug details table below the main table
        container.appendChild(drugTable);
    }
});
