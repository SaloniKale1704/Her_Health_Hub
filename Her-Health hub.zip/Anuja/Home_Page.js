document.addEventListener("DOMContentLoaded", function() {
  var searchButton = document.getElementById("searchButton");

  searchButton.addEventListener("click", function() {
    search();
  });

  function search() {
    var selectedDisease = document.getElementById("categorySelect").value;
    var table = document.getElementById("resultTable");
    var resultBody = document.getElementById("resultBody");

    // Clear previous results
    resultBody.innerHTML = "";

    // Fetch data based on selected disease
    // You can make an AJAX request here to fetch data from your server/database
    
    // Example data
    var data = [];

    switch(selectedDisease.toLowerCase()) {
      case "breast cancer":
        data = [
          { Mild: "Tamoxifen ", Chronic: "Doxorubicin" },
          { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
          { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
          { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
          { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
          { Mild: "Abemaciclib ", Chronic: "Evista " },
          { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
          { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
            ];
        break;
      case "pcod":
        data = [
          { Mild: "PTamoxifen ", Chronic: "Doxorubicin" },
          { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
          { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
          { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
          { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
          { Mild: "Abemaciclib ", Chronic: "Evista " },
          { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
          { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
            ];
        break;
      case "thyroid":
        data = [
          { Mild: "TTamoxifen ", Chronic: "Doxorubicin" },
          { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
          { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
          { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
          { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
          { Mild: "Abemaciclib ", Chronic: "Evista " },
          { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
          { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
            ];
        break;
      case "cervical cancer":
        data = [
          { Mild: "CTamoxifen ", Chronic: "Doxorubicin" },
          { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
          { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
          { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
          { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
          { Mild: "Abemaciclib ", Chronic: "Evista " },
          { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
          { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
            ];
        break;
      case "uterian fibroids":
        data = [
          { Mild: "UTamoxifen ", Chronic: "Doxorubicin" },
          { Mild: "Aromatase inhibitor ", Chronic: "Paclitaxel " },
          { Mild: "Lapatinib  ", Chronic: "Capecitabine" },
          { Mild: "Neratinib  ", Chronic: "Cyclophosphamide" },
          { Mild: "Palbociclib ", Chronic: "Carboplatin  " },
          { Mild: "Abemaciclib ", Chronic: "Evista " },
          { Mild: "Pertuzumab   ", Chronic: "Epirubicin " },
          { Mild: "Trastuzumab  ", Chronic: "Fluorouracil  " },
            ];
        break;
      default:
        break;
    }

    // Populate table with fetched data
    for (var i = 0; i < data.length; i++) {
      var row = document.createElement("tr");
      row.innerHTML = "<td>" + data[i].Mild + "</td><td>" + data[i].Chronic;
      resultBody.appendChild(row);
    }

    // Show the table
    table.style.display = "table";
  }
});
